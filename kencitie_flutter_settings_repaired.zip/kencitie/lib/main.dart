import 'package:flutter/material.dart';

void main() => runApp(const KencitieApp());

const ink = Color(0xFF17212B);
const muted = Color(0xFF74818D);
const canvas = Color(0xFFF4F7F8);
const violet = Color(0xFF6658D3);
const mint = Color(0xFF16B89A);
const bubble = Color(0xFFE8E5FF);

final ValueNotifier<ThemeMode> kencitieThemeMode =
    ValueNotifier<ThemeMode>(ThemeMode.light);

class KencitieApp extends StatelessWidget {
  const KencitieApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: kencitieThemeMode,
      builder: (context, mode, _) => MaterialApp(
        title: 'Kencitie',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(seedColor: violet,
            brightness: Brightness.light, surface: Colors.white),
          fontFamily: 'Roboto',
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white, foregroundColor: ink,
            elevation: 0, centerTitle: false),
        ),
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF101820),
          colorScheme: ColorScheme.fromSeed(
            seedColor: violet,
            brightness: Brightness.dark,
            surface: const Color(0xFF1B2632),
          ),
          fontFamily: 'Roboto',
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF1B2632),
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: false,
          ),
        ),
        home: const PhoneRegistrationPage(),
      ),
    );
  }
}

class Chat {
  final String name, message, time, initials;
  final Color color;
  final int unread;
  final bool online;
  const Chat(this.name, this.message, this.time, this.initials, this.color,
      {this.unread = 0, this.online = false});
}

const demoChats = [
  Chat('Amara James', 'Are we still meeting this evening?', '2:41 PM', 'AJ',
      Color(0xFFFFB86B), unread: 2, online: true),
  Chat('Project Team', 'Daniel: I have shared the latest files', '1:18 PM',
      'PT', Color(0xFF7C9CE8), unread: 4),
  Chat('Mum ❤️', 'Thank you, speak soon!', '11:52 AM', 'M',
      Color(0xFFE88FA8), online: true),
  Chat('David Mensah', 'Voice message · 0:18', 'Yesterday', 'DM',
      Color(0xFF55BFA8)),
  Chat('Weekend Plans', 'You: Sounds like a plan 👍', 'Yesterday', 'WP',
      Color(0xFFB28BE0)),
  Chat('Sarah', 'Photo', 'Monday', 'S', Color(0xFFE4A45D)),
];



class PhoneRegistrationPage extends StatefulWidget {
  const PhoneRegistrationPage({super.key});
  @override
  State<PhoneRegistrationPage> createState() => _PhoneRegistrationPageState();
}

class _PhoneRegistrationPageState extends State<PhoneRegistrationPage> {
  final phoneController = TextEditingController();
  final otpController = TextEditingController();
  String countryCode = '+974';
  bool codeSent = false;

  @override
  void dispose() {
    phoneController.dispose();
    otpController.dispose();
    super.dispose();
  }

  void showSetupNotice() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('SMS verification is a UI preview. Connect Firebase Phone Auth to send and verify real OTP codes.'),
      duration: Duration(seconds: 4),
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(26, 50, 26, 28),
          shrinkWrap: true,
          children: [
            const Center(child: BrandMark()),
            const SizedBox(height: 42),
            Container(
              width: 76, height: 76, alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [violet, mint]),
                borderRadius: BorderRadius.circular(25)),
              child: const Icon(Icons.phone_iphone_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(height: 26),
            Text(codeSent ? 'Verify your number' : 'Welcome to Kencitie',
              style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 9),
            Text(codeSent
              ? 'Enter the one-time code sent to $countryCode ${phoneController.text}.'
              : 'Connect with people who matter. Enter your phone number to get started.',
              style: const TextStyle(color: muted, height: 1.5)),
            const SizedBox(height: 28),
            if (!codeSent) ...[
              const Text('Phone number', style: TextStyle(fontWeight: FontWeight.w700, color: ink)),
              const SizedBox(height: 9),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                  child: DropdownButton<String>(
                    value: countryCode, underline: const SizedBox(),
                    items: const [
                      DropdownMenuItem(value: '+974', child: Text('+974')),
                      DropdownMenuItem(value: '+1', child: Text('+1')),
                      DropdownMenuItem(value: '+44', child: Text('+44')),
                      DropdownMenuItem(value: '+91', child: Text('+91')),
                      DropdownMenuItem(value: '+971', child: Text('+971')),
                      DropdownMenuItem(value: '+234', child: Text('+234')),
                      DropdownMenuItem(value: '+27', child: Text('+27')),
                    ],
                    onChanged: (v) => setState(() => countryCode = v ?? '+974'),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(child: TextField(
                  controller: phoneController, keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: 'Phone number', filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
                )),
              ]),
              const SizedBox(height: 18),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: violet, padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: () {
                  if (phoneController.text.trim().length < 5) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid phone number.')));
                    return;
                  }
                  setState(() => codeSent = true);
                  showSetupNotice();
                },
                child: const Text('Continue with phone number'),
              ),
            ] else ...[
              TextField(
                controller: otpController, keyboardType: TextInputType.number,
                textAlign: TextAlign.center, maxLength: 6,
                style: const TextStyle(fontSize: 25, letterSpacing: 12, fontWeight: FontWeight.bold),
                decoration: InputDecoration(
                  hintText: '••••••', counterText: '', filled: true, fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
              ),
              const SizedBox(height: 14),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: violet, padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: showSetupNotice,
                child: const Text('Verify code'),
              ),
              TextButton(onPressed: () => setState(() { codeSent = false; otpController.clear(); }),
                child: const Text('Change phone number')),
            ],
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () => Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (_) => const HomeShell())),
              icon: const Icon(Icons.visibility_outlined),
              label: const Text('Preview the app without signing in'),
            ),
            const SizedBox(height: 18),
            const Text('By continuing, you agree to Kencitie’s Terms and Privacy Policy.',
              textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11, height: 1.5)),
          ],
        ),
      ),
    )),
  );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  final List<Chat> chats = List.of(demoChats);
  final List<String> titles = ['Chats', 'Updates', 'Calls', 'Settings'];

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 760;
    final pages = [
      ChatsPage(chats: chats, onOpen: (c) => Navigator.push(context,
        MaterialPageRoute(builder: (_) => ConversationPage(chat: c)))),
      const UpdatesPage(),
      const CallsPage(),
      const SettingsPage(),
    ];
    return Scaffold(
      body: SafeArea(
        child: wide
          ? Row(children: [
              NavigationRail(
                selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
                labelType: NavigationRailLabelType.all,
                backgroundColor: Colors.white,
                leading: const Padding(padding: EdgeInsets.symmetric(vertical: 24),
                  child: BrandMark(compact: true)),
                destinations: const [
                  NavigationRailDestination(icon: Icon(Icons.chat_bubble_outline), label: Text('Chats')),
                  NavigationRailDestination(icon: Icon(Icons.circle_outlined), label: Text('Updates')),
                  NavigationRailDestination(icon: Icon(Icons.call_outlined), label: Text('Calls')),
                  NavigationRailDestination(icon: Icon(Icons.settings_outlined), label: Text('Settings')),
                ],
              ),
              const VerticalDivider(width: 1),
              Expanded(child: pages[tab]),
            ])
          : pages[tab],
      ),
      bottomNavigationBar: wide ? null : NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: Colors.white,
        indicatorColor: violet.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.circle_outlined), selectedIcon: Icon(Icons.donut_large), label: 'Updates'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'Calls'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class BrandMark extends StatelessWidget {
  final bool compact;
  const BrandMark({super.key, this.compact = false});
  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: compact ? MainAxisSize.min : MainAxisSize.max,
    children: [
      Container(width: 38, height: 38,
        decoration: BoxDecoration(gradient: const LinearGradient(
          colors: [violet, mint], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(13)),
        child: const Icon(Icons.forum_rounded, color: Colors.white, size: 22)),
      if (!compact) ...[
        const SizedBox(width: 10),
        const Text('Kencitie', style: TextStyle(fontSize: 23,
          fontWeight: FontWeight.w800, color: ink, letterSpacing: -.7)),
      ],
    ],
  );
}

class ChatsPage extends StatelessWidget {
  final List<Chat> chats;
  final ValueChanged<Chat> onOpen;
  const ChatsPage({super.key, required this.chats, required this.onOpen});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
        child: Row(children: [
          const Expanded(child: BrandMark()),
          IconButton(onPressed: () => _snack(context, 'Search will connect to your contacts and messages.'),
            icon: const Icon(Icons.search_rounded)),
          IconButton(onPressed: () => _snack(context, 'New chat: connect your account to find people.'),
            icon: const Icon(Icons.edit_square)),
        ])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Text('Your conversations', style: TextStyle(color: muted, fontSize: 13))),
      const SizedBox(height: 12),
      Expanded(child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
        itemCount: chats.length,
        separatorBuilder: (_, __) => const SizedBox(height: 3),
        itemBuilder: (context, i) {
          final c = chats[i];
          return Material(color: Colors.white, borderRadius: BorderRadius.circular(18),
            child: InkWell(borderRadius: BorderRadius.circular(18),
              onTap: () => onOpen(c),
              child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                Avatar(chat: c, size: 52),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700, color: ink)),
                  const SizedBox(height: 5),
                  Text(c.message, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: muted, fontSize: 13)),
                ])),
                const SizedBox(width: 8),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(c.time, style: const TextStyle(color: muted, fontSize: 11)),
                  const SizedBox(height: 7),
                  if (c.unread > 0) Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: const BoxDecoration(color: mint, shape: BoxShape.circle),
                    child: Text('${c.unread}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
                  if (c.online && c.unread == 0) const Icon(Icons.done_all, size: 16, color: mint),
                ]),
              ]))),
          );
        },
      )),
    ],
  );
}

class Avatar extends StatelessWidget {
  final Chat chat;
  final double size;
  const Avatar({super.key, required this.chat, this.size = 48});
  @override
  Widget build(BuildContext context) => Stack(children: [
    CircleAvatar(radius: size / 2, backgroundColor: chat.color,
      child: Text(chat.initials, style: TextStyle(color: Colors.white,
        fontWeight: FontWeight.w800, fontSize: size * .29))),
    if (chat.online) Positioned(right: 0, bottom: 0,
      child: Container(width: 12, height: 12,
        decoration: BoxDecoration(color: mint, shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2)))),
  ]);
}

class ConversationPage extends StatefulWidget {
  final Chat chat;
  const ConversationPage({super.key, required this.chat});
  @override
  State<ConversationPage> createState() => _ConversationPageState();
}

class _ConversationPageState extends State<ConversationPage> {
  final controller = TextEditingController();
  final messages = <String>[
    'Hey! How is your day going?',
    'Pretty good, thanks. Just wrapping up a few things.',
    'Are we still meeting this evening?',
  ];
  @override
  void dispose() { controller.dispose(); super.dispose(); }

  void send() {
    final value = controller.text.trim();
    if (value.isEmpty) return;
    setState(() { messages.add(value); controller.clear(); });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: const BackButton(),
      title: Row(children: [
        Avatar(chat: widget.chat, size: 38), const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.chat.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          Text(widget.chat.online ? 'online' : 'last seen recently',
            style: const TextStyle(fontSize: 11, color: muted)),
        ]),
      ]),
      actions: [
        IconButton(onPressed: () => _snack(context, 'Voice calling requires the call service to be configured.'),
          icon: const Icon(Icons.call_outlined)),
        IconButton(onPressed: () => _snack(context, 'Video calling requires the call service to be configured.'),
          icon: const Icon(Icons.videocam_outlined)),
      ],
    ),
    body: Column(children: [
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(16), itemCount: messages.length,
        itemBuilder: (_, i) {
          final mine = i == messages.length - 1;
          return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              constraints: const BoxConstraints(maxWidth: 310),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                color: mine ? bubble : Colors.white,
                borderRadius: BorderRadius.circular(18).copyWith(
                  bottomRight: mine ? const Radius.circular(5) : null,
                  bottomLeft: mine ? null : const Radius.circular(5)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(messages[i], style: const TextStyle(color: ink, height: 1.35)),
                const SizedBox(height: 4),
                const Text('now  ✓✓', style: TextStyle(fontSize: 9, color: muted)),
              ]),
            ));
        },
      )),
      Container(color: Colors.white, padding: const EdgeInsets.fromLTRB(12, 9, 12, 12),
        child: Row(children: [
          IconButton(onPressed: () => _snack(context, 'Attachments will be enabled with media storage.'),
            icon: const Icon(Icons.add_circle_outline, color: violet)),
          Expanded(child: TextField(controller: controller,
            textInputAction: TextInputAction.send, onSubmitted: (_) => send(),
            decoration: InputDecoration(hintText: 'Write a message',
              filled: true, fillColor: canvas, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none)))),
          const SizedBox(width: 7),
          IconButton.filled(onPressed: send, style: IconButton.styleFrom(backgroundColor: violet),
            icon: const Icon(Icons.send_rounded, color: Colors.white)),
        ]),
      ),
    ]),
  );
}

class UpdatesPage extends StatelessWidget {
  const UpdatesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Updates', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Share a moment', style: TextStyle(color: ink, fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      Card(color: Colors.white, child: ListTile(
        leading: Container(width: 48, height: 48,
          decoration: BoxDecoration(color: violet.withOpacity(.1), borderRadius: BorderRadius.circular(16)),
          child: const Icon(Icons.add, color: violet)),
        title: const Text('My status', style: TextStyle(fontWeight: FontWeight.w700)),
        subtitle: const Text('Share a photo, video or text update'),
        onTap: () => _snack(context, 'Status composer will be connected to media storage.'))),
      const SizedBox(height: 22),
      const Text('Recent updates', style: TextStyle(color: muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      const ListTile(leading: CircleAvatar(backgroundColor: Color(0xFFFFB86B), child: Text('AJ')),
        title: Text('Amara James'), subtitle: Text('Today, 10:24 AM')),
      const ListTile(leading: CircleAvatar(backgroundColor: Color(0xFF7C9CE8), child: Text('PT')),
        title: Text('Project Team'), subtitle: Text('Today, 8:12 AM')),
    ]),
  );
}

class CallsPage extends StatelessWidget {
  const CallsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Calls', style: TextStyle(fontWeight: FontWeight.w800)),
      actions: [IconButton(onPressed: () => _snack(context, 'Call contacts will appear here.'),
        icon: const Icon(Icons.add_call))]),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Stay connected', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 6),
      const Text('Your recent voice and video calls will appear here.', style: TextStyle(color: muted)),
      const SizedBox(height: 20),
      const _CallRow(name: 'Amara James', detail: 'Incoming voice call · Today, 2:10 PM', video: false),
      const _CallRow(name: 'Project Team', detail: 'Outgoing video call · Yesterday', video: true),
    ]),
  );
}

class _CallRow extends StatelessWidget {
  final String name, detail;
  final bool video;
  const _CallRow({required this.name, required this.detail, required this.video});
  @override
  Widget build(BuildContext context) => Card(color: Colors.white, child: ListTile(
    leading: CircleAvatar(backgroundColor: violet.withOpacity(.12),
      child: Icon(video ? Icons.videocam_outlined : Icons.call_outlined, color: violet)),
    title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text(detail, style: const TextStyle(fontSize: 11, color: muted)),
    trailing: Icon(video ? Icons.videocam : Icons.call, color: mint),
  ));
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text(
      'Settings', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _open(context, const ProfileSettingsPage()),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [violet, mint]),
            ),
            child: const Row(children: [
              CircleAvatar(radius: 27, backgroundColor: Colors.white24,
                child: Icon(Icons.person, color: Colors.white, size: 30)),
              SizedBox(width: 14),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Your Kencitie profile',
                    style: TextStyle(color: Colors.white,
                      fontWeight: FontWeight.bold, fontSize: 17)),
                  Text('Set up your name and profile photo',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              )),
              Icon(Icons.chevron_right, color: Colors.white),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 14),
      _setting(context, Icons.person_outline, 'Account',
        'Privacy, security and number',
        const AccountSettingsPage()),
      _setting(context, Icons.lock_outline, 'Privacy',
        'Last seen, profile photo and blocks',
        const PrivacySettingsPage()),
      _setting(context, Icons.notifications_none, 'Notifications',
        'Message and call alerts',
        const NotificationSettingsPage()),
      _setting(context, Icons.palette_outlined, 'Appearance',
        'Theme and chat wallpaper',
        const AppearancePage()),
      _setting(context, Icons.help_outline, 'Help',
        'Help centre and contact support',
        const HelpSettingsPage()),
      const Padding(padding: EdgeInsets.all(16), child: Text(
        'Kencitie · Early preview', textAlign: TextAlign.center,
        style: TextStyle(color: muted, fontSize: 11))),
    ]),
  );

  Widget _setting(BuildContext context, IconData icon, String title,
      String subtitle, Widget page) => Card(
    color: Theme.of(context).colorScheme.surface,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      leading: Icon(icon, color: violet),
      title: Text(title,
        style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle,
        style: const TextStyle(color: muted, fontSize: 12)),
      trailing: const Icon(Icons.chevron_right, color: muted),
      onTap: () => _open(context, page),
    ),
  );
}

class ProfileSettingsPage extends StatefulWidget {
  const ProfileSettingsPage({super.key});
  @override
  State<ProfileSettingsPage> createState() => _ProfileSettingsPageState();
}

class _ProfileSettingsPageState extends State<ProfileSettingsPage> {
  final _nameController = TextEditingController();
  final _aboutController = TextEditingController(text: 'Available on Kencitie');

  @override
  void dispose() {
    _nameController.dispose();
    _aboutController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Your profile')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Center(child: CircleAvatar(radius: 46,
        child: Icon(Icons.person, size: 48))),
      const SizedBox(height: 24),
      TextField(controller: _nameController,
        decoration: const InputDecoration(
          labelText: 'Name', border: OutlineInputBorder())),
      const SizedBox(height: 16),
      TextField(controller: _aboutController,
        decoration: const InputDecoration(
          labelText: 'About', border: OutlineInputBorder())),
      const SizedBox(height: 18),
      FilledButton(
        onPressed: () => _snack(context,
          'Profile editing is a local preview. Saving to your account will be enabled after sign-in is connected.'),
        child: const Text('Save profile')),
      const SizedBox(height: 8),
      const Text('Profile photo upload and cloud profile saving will be connected with account setup.',
        style: TextStyle(color: muted)),
    ]),
  );
}

class AccountSettingsPage extends StatelessWidget {
  const AccountSettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Account')),
    body: ListView(children: [
      const ListTile(
        leading: Icon(Icons.phone_android),
        title: Text('Phone number'),
        subtitle: Text('Your verified phone number will appear here after sign-in.'),
      ),
      const Divider(height: 1),
      ListTile(
        leading: const Icon(Icons.security),
        title: const Text('Security'),
        subtitle: const Text('Account security options'),
        onTap: () => _snack(context,
          'Security settings will be available after Firebase authentication is connected.'),
      ),
      ListTile(
        leading: const Icon(Icons.devices),
        title: const Text('Linked devices'),
        subtitle: const Text('Manage devices signed in to your account'),
        onTap: () => _snack(context,
          'Linked devices will be available after account sign-in is connected.'),
      ),
      ListTile(
        leading: const Icon(Icons.delete_outline),
        title: const Text('Delete account'),
        subtitle: const Text('Account deletion information'),
        onTap: () => _snack(context,
          'Account deletion is not available in this preview.'),
      ),
    ]),
  );
}

class PrivacySettingsPage extends StatefulWidget {
  const PrivacySettingsPage({super.key});
  @override
  State<PrivacySettingsPage> createState() => _PrivacySettingsPageState();
}

class _PrivacySettingsPageState extends State<PrivacySettingsPage> {
  bool lastSeen = true;
  bool profilePhoto = true;
  bool readReceipts = true;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Privacy')),
    body: ListView(children: [
      SwitchListTile(
        title: const Text('Last seen'),
        subtitle: const Text('Show when you were last active (preview only)'),
        value: lastSeen,
        onChanged: (v) => setState(() => lastSeen = v)),
      SwitchListTile(
        title: const Text('Profile photo'),
        subtitle: const Text('Allow others to see your profile photo (preview only)'),
        value: profilePhoto,
        onChanged: (v) => setState(() => profilePhoto = v)),
      SwitchListTile(
        title: const Text('Read receipts'),
        subtitle: const Text('Show read confirmations (preview only)'),
        value: readReceipts,
        onChanged: (v) => setState(() => readReceipts = v)),
      ListTile(
        leading: const Icon(Icons.block),
        title: const Text('Blocked contacts'),
        subtitle: const Text('Manage blocked contacts'),
        onTap: () => _snack(context,
          'Blocked contacts will be available after contacts and accounts are connected.')),
    ]),
  );
}

class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({super.key});
  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  bool messages = true;
  bool groups = true;
  bool calls = true;
  bool previews = true;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notifications')),
    body: ListView(children: [
      SwitchListTile(
        title: const Text('Message notifications'),
        value: messages,
        onChanged: (v) => setState(() => messages = v)),
      SwitchListTile(
        title: const Text('Group notifications'),
        value: groups,
        onChanged: (v) => setState(() => groups = v)),
      SwitchListTile(
        title: const Text('Call notifications'),
        value: calls,
        onChanged: (v) => setState(() => calls = v)),
      SwitchListTile(
        title: const Text('Show message previews'),
        value: previews,
        onChanged: (v) => setState(() => previews = v)),
      const Padding(
        padding: EdgeInsets.all(16),
        child: Text('These switches demonstrate the settings interface. System push notifications require backend configuration.',
          style: TextStyle(color: muted))),
    ]),
  );
}

class AppearancePage extends StatelessWidget {
  const AppearancePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text(
      'Appearance', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ValueListenableBuilder<ThemeMode>(
      valueListenable: kencitieThemeMode,
      builder: (context, selectedMode, _) => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Theme', style: TextStyle(
            fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Choose how Kencitie looks. Your selection applies immediately.',
            style: TextStyle(color: muted)),
          const SizedBox(height: 14),
          Card(child: Column(children: [
            RadioListTile<ThemeMode>(
              value: ThemeMode.light, groupValue: selectedMode,
              title: const Text('Light mode'),
              secondary: const Icon(Icons.light_mode_outlined),
              onChanged: (value) {
                if (value != null) kencitieThemeMode.value = value;
              }),
            const Divider(height: 1),
            RadioListTile<ThemeMode>(
              value: ThemeMode.dark, groupValue: selectedMode,
              title: const Text('Dark mode'),
              secondary: const Icon(Icons.dark_mode_outlined),
              onChanged: (value) {
                if (value != null) kencitieThemeMode.value = value;
              }),
            const Divider(height: 1),
            RadioListTile<ThemeMode>(
              value: ThemeMode.system, groupValue: selectedMode,
              title: const Text('Use device settings'),
              secondary: const Icon(Icons.settings_brightness_outlined),
              onChanged: (value) {
                if (value != null) kencitieThemeMode.value = value;
              }),
          ])),
          const SizedBox(height: 20),
          const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.wallpaper_outlined, color: violet),
            title: Text('Chat wallpaper'),
            subtitle: Text('Wallpaper choices will be added in a future update.'),
          ),
        ],
      ),
    ),
  );
}

class HelpSettingsPage extends StatelessWidget {
  const HelpSettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Help')),
    body: ListView(children: [
      ListTile(
        leading: const Icon(Icons.help_outline),
        title: const Text('Frequently asked questions'),
        subtitle: const Text('Learn how to use Kencitie'),
        onTap: () => _showHelp(context, 'Frequently asked questions',
          'Kencitie is currently an early preview. Account registration, messaging and calling will be enabled as the services are connected.')),
      ListTile(
        leading: const Icon(Icons.chat_bubble_outline),
        title: const Text('Contact support'),
        subtitle: const Text('Get help with Kencitie'),
        onTap: () => _showHelp(context, 'Contact support',
          'Support contact details will be added before public launch.')),
      ListTile(
        leading: const Icon(Icons.info_outline),
        title: const Text('About Kencitie'),
        subtitle: const Text('Version 0.1.0 · Early preview'),
        onTap: () => _showHelp(context, 'About Kencitie',
          'Kencitie is a communication app prototype. Some features are demonstration-only.')),
    ]),
  );

  void _showHelp(BuildContext context, String title, String message) {
    showDialog<void>(context: context, builder: (dialogContext) =>
      AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [TextButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: const Text('Close'))],
      ));
  }
}

void _snack(BuildContext context, String text) =>
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
