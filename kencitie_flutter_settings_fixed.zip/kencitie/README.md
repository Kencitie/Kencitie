# Kencitie — Flutter starter

Kencitie is a cross-platform Flutter starter for an original messaging app experience. It includes a responsive UI shell for Android, iOS and web, sample conversation data, a locally interactive chat composer, Updates, Calls and Settings screens.

## Run locally

1. Install Flutter (stable) and the Android/iOS/web toolchains.
2. Unzip this project.
3. In the project directory run:

```bash
flutter pub get
flutter run -d chrome
```

For Android, run `flutter run` with an emulator or device attached. For iOS, use macOS with Xcode and run `flutter run` with an iPhone simulator/device.

## Important: prototype versus production

This starter is an interactive front-end prototype. The sample conversations are local demo data. It includes a phone-number registration and OTP-entry **UI preview** (not connected to an SMS provider). It does **not** yet provide real accounts, delivery between devices, push notifications, media uploads, end-to-end encryption, or live voice/video calling.

## Production architecture to add

- Authentication: Firebase Authentication Phone Auth for phone-only sign-in. Configure allowed regions, SMS quotas, abuse protections and platform app verification (Android Play Integrity / iOS APNs or reCAPTCHA as required). Do not treat the current OTP screen as real verification.
- Data: PostgreSQL for users, conversations, memberships and message metadata.
- Realtime: authenticated WebSocket gateway (e.g. Socket.IO) for message delivery and presence.
- Media: private object storage with signed upload/download URLs and malware/content checks.
- Push: Firebase Cloud Messaging and APNs.
- Voice/video: WebRTC with STUN/TURN; use a managed SFU for group calls.
- Security: TLS, device/session management, rate limits, abuse reporting, key management and a reviewed end-to-end encryption protocol.

## Suggested next milestone

Implement sign-up/login and a real backend data model before enabling real messaging. Voice/video calling should be added after identity, permissions, signaling and TURN infrastructure are in place.
