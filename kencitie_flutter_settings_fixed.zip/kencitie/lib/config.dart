// Keep environment-specific endpoints and public configuration here.
// Never commit private API keys, service-account files, or signing secrets.
class AppConfig {
  static const appName = 'Kencitie';
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL');
}
